package ssl;

import android.os.Build;

public class SslConfigManager {

    // Enable Conscrypt for devices older than Android 10 (API 29) to backport TLS 1.3
    private static boolean useConscrypt = Build.VERSION.SDK_INT < Build.VERSION_CODES.Q;

    // Enable insecure SSL fallbacks
    private static boolean enableInsecureSSL = true;

    // Use legacy TLS configurations for pre-Lollipop devices (< API 21)
    private static boolean legacyTlsForOldAndroid = Build.VERSION.SDK_INT < Build.VERSION_CODES.LOLLIPOP;

    public static boolean isUseConscrypt() {
        return useConscrypt;
    }

    public static boolean isEnableInsecureSSL() {
        return enableInsecureSSL;
    }

    public static boolean isLegacyTlsForOldAndroid() {
        return legacyTlsForOldAndroid;
    }
}