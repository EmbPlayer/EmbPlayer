package server.tools;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import app.tools.Recyclable;
import app.tools.StaticFunctions;

public abstract class HttpServletAdvanced extends HttpServlet {

    protected static final Recyclable.ListDisposable actions = new Recyclable.ListDisposable(HttpServletAdvanced.class);

    @Override
    protected final void doGet(HttpServletRequest req, HttpServletResponse resp) {
        resp.addHeader("Access-Control-Allow-Origin", "*");
        resp.addHeader("Access-Control-Allow-Methods", "GET, POST");/*, PUT, DELETE, OPTIONS*/
        resp.setCharacterEncoding("UTF-8");
        //resp.setContentType("application/json; charset=UTF-8");

        try {
            doGetAdvanced(req, resp);
        } catch (IOException | ServletException e) {
            StaticFunctions.onThrows(e);
        }
    }

    @Override
    protected final void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        try {
            doPostAdvanced(req,resp);
        } catch (IOException | ServletException e) {
            StaticFunctions.onThrows(e);
        }
    }

    protected void doPostAdvanced(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        super.doPost(request,response);
    }

    protected void doGetAdvanced(HttpServletRequest request, HttpServletResponse response) throws IOException, ServletException {
        super.doGet(request,response);
    }
}
