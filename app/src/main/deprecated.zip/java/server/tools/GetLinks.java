package server.tools;

import java.io.IOException;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class GetLinks  extends HttpServletAdvanced {

    protected String get()
    {
        //String newline = System.getProperty("line.separator");

        String outPut = "";
        //String outPut = ""+App().ErrorHandel.mediaSession.getSecond();

        /*
        String outPut = "videoStreams :"+newline+newline;
        for(int i = 0; i<App().videoStreamList.size(); i++)
        {
            outPut = outPut+Uri.parse(App().videoStreamList.get(i).getContent()).toString()+newline+newline+newline;
        }

        outPut = outPut+"videoOnlyStreams :"+newline+newline;
        for(int i = 0; i<App().videoOnlyStreamList.size(); i++)
        {
            outPut = outPut+ Uri.parse(App().videoOnlyStreamList.get(i).getContent()).toString()+newline+newline+newline;
        }

        outPut = outPut+"audioStreams :"+newline+newline;
        for(int i = 0; i<App().audioStreams.size(); i++)
        {
            outPut = outPut+Uri.parse(App().audioStreams.get(i).getContent()).toString()+newline+newline+newline;
        }*/

        //outPut = outPut+newline+newline+App().language;
/*
        for(int i = 0; i<App().logs.size(); i++)
        {
            outPut = outPut+App().logs.get(i)+newline+newline+newline;
        }

        outPut = outPut + newline+newline+App().hls;*/

        return outPut;

        /*try {
            return App().hls;
        }
        catch (Exception l)
        {
            return null;
        }*/
    }


    @Override
    protected void doGetAdvanced(HttpServletRequest req, HttpServletResponse resp) throws IOException {
        resp.getWriter().write(get());
    }
}
