package server.tools;

import android.content.Context;
import android.net.wifi.WifiManager;

import org.xbill.DNS.Name;
import org.xbill.mDNS.MulticastDNSService;
import org.xbill.mDNS.ServiceInstance;
import org.xbill.mDNS.ServiceName;

import java.net.InetAddress;

import io.reactivex.rxjava3.disposables.Disposable;

import static app.tools.DisposableTools.addTask;
import static app.tools.DisposableTools.forkJoinPool;

public class Mdns {

    private MulticastDNSService mDNSService;
    private WifiManager.MulticastLock multicastLock;
    private Disposable mdnsTask;

    public Mdns(Context context, String instanceName, String hostName, String ip, int port) {
        mdnsTask = addTask(() -> {
            WifiManager wifi = (WifiManager) context.getApplicationContext()
                    .getSystemService(Context.WIFI_SERVICE);
            multicastLock = wifi.createMulticastLock("mdns_lock");
            multicastLock.setReferenceCounted(true);
            multicastLock.acquire();

            try {
                // 1. PROPER SERVICE NAME CONSTRUCTION
                String fullServiceName = instanceName + "._http._tcp.local.";
                ServiceName name = new ServiceName(fullServiceName);

                // 2. HOSTNAME MUST END WITH DOT
                Name hName = new Name(hostName.endsWith(".") ? hostName : hostName + ".");

                // 3. IP ADDRESS
                InetAddress ip4 = InetAddress.getByName(ip);

                // 4. MANDATORY TXT RECORDS
                String[] txtRecords = {
                        /*"txtvers=1",*/
                        "ip="+ip,
                        "hostname="+ip4.getHostName()
                };

                // 5. CREATE INSTANCE
                ServiceInstance instance = new ServiceInstance(
                        name, 0, 0, port, hName,
                        new InetAddress[]{ip4},
                        txtRecords
                );

                // 6. REGISTER SERVICE
                mDNSService = new MulticastDNSService();
                mDNSService.register(instance);

            } catch (Exception e) {
                e.printStackTrace();
                return false;
            }
            return true;
        },() -> "Mdns",forkJoinPool);
    }

    public void stopAdvertisement() {
        if (mdnsTask != null && !mdnsTask.isDisposed()) {
            mdnsTask.dispose();
        }
    }
}
