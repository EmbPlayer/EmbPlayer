package server.tools;

import app.tools.Generators.Requirements.Piped.VideoQuality;
import app.tools.Generators.Requirements.Piped.VideoResolution;

public class VideoSettings {
    private VideoResolution resolution;
    private VideoResolution resolutionLive;
    private VideoQuality quality;
    private String language;

    private VideoResolution savedLiveResolution;
    private VideoResolution savedResolution;
    private VideoQuality savedQuality;
    private String savedLanguage;

    public VideoSettings(VideoResolution resLive,VideoResolution res, VideoQuality quali, String languageISO2)
    {
        resolutionLive = resLive;
        resolution = res;
        quality = quali;
        language = languageISO2;
    }

    public VideoResolution resolution()
    {
        return resolution;
    }
    public VideoResolution resolutionLive()
    {
        return resolutionLive;
    }
    public VideoQuality quality()
    {
        return quality;
    }
    public String languageISO2()
    {
        return language;
    }

    public void resetToDefault()
    {
        resolutionLive = savedLiveResolution;
        resolution = savedResolution;
        quality = savedQuality;
        language = savedLanguage;
    }

    public void backgroudMod()
    {
        save();
        quality = VideoQuality.LEAST_BANDWIDTH;
        resolution = VideoResolution.Audio;
        resolutionLive = VideoResolution.Audio;
    }

    private void save()
    {
        savedLiveResolution = resolutionLive;
        savedResolution = resolution;
        savedQuality = quality;
        savedLanguage = language;
    }
}
