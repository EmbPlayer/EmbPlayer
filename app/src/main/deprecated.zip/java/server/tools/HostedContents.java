package server.tools;

import org.eclipse.jetty.servlet.ServletContextHandler;

import java.io.IOException;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import app.services.BaseServer;
import server.JettyServer;

public class HostedContents {
    private static GetContent audio;
    private static GetContent video;

    public static GetContent getAudioOrBase() {
        return audio;
    }

    public static GetContent getVideo() {
        return video;
    }

    public static void generateProxies(ServletContextHandler handler) {
        audio = new GetContent("/AudioStream", handler);
        video = new GetContent("/VideoStream", handler);
    }

    public static void nullAll() {
        audio.content = null;
        video.content = null;
    }

    public static class GetContent extends HttpServletAdvanced {
        private String content;
        private final String contentPath;

        public GetContent(String contentPath, ServletContextHandler handler) {
            this.contentPath = contentPath;
            handler.addServlet(new JettyServer.CustomServletHolder(this), this.contentPath);
        }

        public String getContentUrl() {
            return "http://" + BaseServer.getLocalhost() + ":" + BaseServer.getPort() + contentPath;
        }

        public void updateContent(String content) {
            this.content = content;
        }

        @Override
        protected void doGetAdvanced(HttpServletRequest request, HttpServletResponse response) throws IOException {
            if (content == null)
                notFound(response);
            else
                found(response);
        }

        private void notFound(HttpServletResponse response) throws IOException {
            // Handle 404 Not Found
            response.setStatus(HttpServletResponse.SC_NOT_FOUND);
            response.getWriter().println("<h1>404 Not Found</h1>");
        }

        private void found(HttpServletResponse response) throws IOException {
            response.sendRedirect(content);
        }
    }
}