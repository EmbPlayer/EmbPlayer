package server.web;

import org.eclipse.jetty.servlet.ServletContextHandler;

import java.io.IOException;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import app.tools.StaticFunctions;
import server.JettyServer;
import server.tools.HttpServletAdvanced;

import static app.tools.StaticFunctions.ItemWithId;

import static app.tools.StaticFunctions.asJsonFormat;
import static server.Home.app;

public class SavedLinkList  extends HttpServletAdvanced {

    private List<ItemWithId> links;
    private String tableName;

    public SavedLinkList(String tableName)
    {
        this.tableName = tableName;
    }

    public void addToHandler(ServletContextHandler handler)
    {
        handler.addServlet(new JettyServer.CustomServletHolder(this),"/"+tableName);
    }

    @Override
    protected void doGetAdvanced(HttpServletRequest req, HttpServletResponse resp) throws IOException {
        loadList();
        //StaticFunctions.setData(StaticFunctions.ItemWithIdAsJson(links));

        if(links == null|| links.isEmpty())
            resp.getWriter().write("[]");
        else
            resp.getWriter().write(StaticFunctions.setData(StaticFunctions.itemWithIdAsJson(links)));
    }

    private void loadList()
    {
        links = app().getLinks(tableName);
        //links = aa[index];
    }
}
