package server.web;

import java.io.IOException;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import app.tools.LinksDbHelper;
import app.tools.StaticFunctions;
import server.tools.HttpServletAdvanced;

public class Tables extends HttpServletAdvanced {

    @Override
    protected void doGetAdvanced(HttpServletRequest req, HttpServletResponse resp) throws IOException {
        resp.getWriter().write(StaticFunctions.setData(StaticFunctions.itemAsJsonNormal(LinksDbHelper.getTableNames())));
    }

}
