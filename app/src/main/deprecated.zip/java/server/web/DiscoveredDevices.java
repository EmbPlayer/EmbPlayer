package server.web;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import javax.jmdns.ServiceInfo;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import app.tools.StaticFunctions;
import server.tools.HttpServletAdvanced;

import static app.tools.StaticFunctions.asJsonFormat;
import static app.tools.StaticFunctions.Item;

public class DiscoveredDevices extends HttpServletAdvanced {

    private List<Item> devices;

    private boolean updateDevices()
    {
        devices = new ArrayList<>();/*

        for(BonjourService device : UniversalMDNS.Devices())
        {
            //devices.add(device.getHostname());
            Map<String,String> txt = device.getTxtRecords();
            devices.add(new Item(txt.get("device"),txt.get("hostname_link")));
        }*/

        List<ServiceInfo> getDevices = null/*JmdnsHost.Devices()*/;

        if(getDevices==null)
            return false;
/*
        for(ServiceInfo device : getDevices) {
            // JmDNS provides direct methods to access TXT record values as strings
            String deviceName = device.getPropertyString("device");
            String hostnameLink = device.getPropertyString("hostname_link");

            devices.add(new Item(deviceName, hostnameLink));
        }*/

        return false;
    }

    @Override
    protected void doGetAdvanced(HttpServletRequest req, HttpServletResponse resp) throws IOException {

        if(!updateDevices())
            return;

        resp.getWriter().write(StaticFunctions.setData(StaticFunctions.itemAsJson(devices)));
    }
}
