package server.web;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import app.tools.StaticFunctions;
import server.tools.HttpServletAdvanced;

import static app.tools.DisposableTools.waitMS;

public class Wait extends HttpServletAdvanced {

    private static boolean isWaiting;

    public static void webUIWaitStart()
    {
        isWaiting = true;
    }

    public static void webUIWaitStop()
    {
        ErrorCodeApp.code48 = ErrorCodeApp.code48 + StaticFunctions.getInfo("PanelClose");
        isWaiting = false;
    }

    @Override
    protected void doGetAdvanced(HttpServletRequest request, HttpServletResponse response){
        for (int i = 0; i<350; i++)
        {
            waitMS(250);
            if(!isWaiting)
                break;
        }

        response.setStatus(HttpServletResponse.SC_OK);
    }
}
