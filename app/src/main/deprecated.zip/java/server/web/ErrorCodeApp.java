package server.web;

import android.app.ActivityManager;
import android.content.Context;

import java.io.IOException;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import app.Main;
import app.tools.SData;
import server.tools.HttpServletAdvanced;

public class ErrorCodeApp extends HttpServletAdvanced {
    public static String youtubeExtractorJ = "youtubeExtractorJ";
    public static String liveLoading = "liveLoading";
    public static String ramUsageInApp = "-1";

    public static String code = "-1";
    public static String code2 = "-1";
    public static String code3 = "-1";
    public static String code4 = "-1";
    public static String code5 = "restart ";
    public static String code6 = "-1";
    public static String code7 = "-1";
    public static String code8 = "-1";
    public static String code9 = "-1";
    public static String code10 = "-1";
    public static String code11 = "-1";
    public static String code12 = "-1";
    public static String code13 = "-1";
    public static String code14 = "-1";
    public static String code15 = "-2";
    public static String code16 = "maxSeek";
    public static String code17 = "SSSSSSS";
    public static String code18 = "pause";
    public static String code19 = "-0-";
    public static String code20 = "-0-";
    public static String code21 = "-0-";
    public static String code22 = " |";
    public static String code23 = "savedSeekDinamic: ";
    public static String code24 = "-1";
    public static String code25 = "AllStopings: ";
    public static String code26 = "-01-";
    public static String code27 = "-01-";
    public static String code28 = "-01-";
    public static String code29 = "MACADDRES";
    public static String code30 = "FirstMediaSesionStart";
    public static String code31 = "SecondMediaSesionStart";
    public static String code32 = "BGLiveCheck: ";
    public static String code33 = "TTT";
    public static String code34 = "";
    public static String code35 = "-212";
    public static String code36 = "-457";
    public static String code37 = "-434";
    public static String code38 = "-O-";
    public static String code39 = "-O-";
    public static String code40 = "-0-";
    public static String code41 = "-0-";
    public static String code42 = "-0-";
    public static String code43 = ".";
    public static String code44 = ".";
    public static String code45 = ".";
    public static String code46 = ".";
    public static String code47 = ".";
    public static String code48 = ".";
    public static String code49 = ".";
    public static String code50 = ".";
    public static String code51 = ".";
    public static String code52 = ".";
    public static String code53 = ".";
    public static String code54 = ".";

    public static void errorLog(String error)
    {
        SData.setString(SData.Data.SaveErrorAA,SData.getString(SData.Data.SaveErrorAA)+"["+error+"]");
        ErrorCodeApp.code38 = SData.getString(SData.Data.SaveErrorAA);
    }

    public static void getSystemMemoryInfo(Context context) {

        String output = "[[System]";

        ActivityManager activityManager = (ActivityManager) context.getSystemService(Context.ACTIVITY_SERVICE);
        ActivityManager.MemoryInfo memoryInfo = new ActivityManager.MemoryInfo();
        activityManager.getMemoryInfo(memoryInfo);

        long totalMemory = memoryInfo.totalMem;
        long availableMemory = memoryInfo.availMem;
        long usedMemory = totalMemory - availableMemory;
        boolean isLowMemory = memoryInfo.lowMemory;
        long threshold = memoryInfo.threshold;



        output = output + System.lineSeparator() + "SystemMemory " + "Total RAM: " + formatSize(totalMemory);
        output = output + System.lineSeparator() + "SystemMemory " + "Available RAM: " + formatSize(availableMemory);
        output = output + System.lineSeparator() + "SystemMemory " + "Used RAM: " + formatSize(usedMemory);
        output = output + System.lineSeparator() + "SystemMemory " + "Low Memory: " + isLowMemory;
        output = output + System.lineSeparator() + "SystemMemory " + "Low Memory Threshold: " + formatSize(threshold);
        output = output + "]";

        ramUsageInApp = ramUsageInApp + System.lineSeparator() + output;
    }

    // Get current app's memory usage
    public static void getCurrentAppMemoryUsage() {
        ramUsageInApp = "";

        Runtime runtime = Runtime.getRuntime();

        long totalMemory = runtime.totalMemory();
        long freeMemory = runtime.freeMemory();
        long usedMemory = totalMemory - freeMemory;
        long maxMemory = runtime.maxMemory();

        String output = "[[RamInApp]";

        output = output + System.lineSeparator() + "totalMemory: " +formatSize(totalMemory);
        output = output + System.lineSeparator() + "freeMemory: " +formatSize(freeMemory);
        output = output + System.lineSeparator() + "usedMemory: " +formatSize(usedMemory);
        output = output + System.lineSeparator() + "maxMemory: " +formatSize(maxMemory);
        output = output + "]";

        ramUsageInApp = output;

        getSystemMemoryInfo(Main.getContext());
    }

    @Override
    protected void doGetAdvanced(HttpServletRequest req, HttpServletResponse resp) throws IOException {
        String k = ramUsageInApp+System.lineSeparator()+youtubeExtractorJ+
                System.lineSeparator()+code39+System.lineSeparator()+code38+
                System.lineSeparator()+code37+System.lineSeparator()+code36+
                System.lineSeparator()+code35+System.lineSeparator()+code34+
                System.lineSeparator()+code33+System.lineSeparator()+code32+
                System.lineSeparator()+code31+System.lineSeparator()+code30+
                System.lineSeparator()+code29+System.lineSeparator()+code28+
                System.lineSeparator()+code27+System.lineSeparator()+code26+
                System.lineSeparator()+code25+System.lineSeparator()+code24+
                System.lineSeparator()+code23+System.lineSeparator()+code22+
                System.lineSeparator()+code21+System.lineSeparator()+code20+
                System.lineSeparator()+code19+System.lineSeparator()+code18+
                System.lineSeparator()+code17+System.lineSeparator()+code16+
                System.lineSeparator()+code15+System.lineSeparator()+code14+
                System.lineSeparator()+code13+System.lineSeparator()+code12+
                System.lineSeparator()+code11+System.lineSeparator()+code+
                System.lineSeparator()+code2+System.lineSeparator()+code3+
                System.lineSeparator()+code4+System.lineSeparator()+code5+
                System.lineSeparator()+code6+System.lineSeparator()+code7+
                System.lineSeparator()+code8+System.lineSeparator()+code9+
                System.lineSeparator()+code10+System.lineSeparator()+liveLoading+
                System.lineSeparator()+code40+System.lineSeparator()+code41+
                System.lineSeparator()+code42+System.lineSeparator()+code43+
                System.lineSeparator()+code44+System.lineSeparator()+code45+
                System.lineSeparator()+code46+System.lineSeparator()+code47+
                System.lineSeparator()+code48+System.lineSeparator()+code49+
                System.lineSeparator()+code50+System.lineSeparator()+code51+
                System.lineSeparator()+code52+System.lineSeparator()+code53+
                System.lineSeparator()+code54;
        resp.getWriter().write(k);
    }

    private static String formatSize(long size) {
        String suffix = "B";
        if (size >= 1024) {
            size /= 1024;
            suffix = "KB";
        }
        if (size >= 1024) {
            size /= 1024;
            suffix = "MB";
        }
        if (size >= 1024) {
            size /= 1024;
            suffix = "GB";
        }
        return size + " " + suffix;
    }
}
