package server;

import app.App.AppBack;
import app.App.AppControl;
import server.tools.GetLinks;

import app.tools.LinksDbHelper;
import server.web.DiscoveredDevices;
import server.web.SavedLinkList;
import server.web.Sources;
import server.web.Tables;
import server.web.VideoProperties;
import server.web.Wait;

public class Home {
    protected final Wait waiter;
    protected final VideoProperties quality;
    protected final GetLinks links;
    protected final DiscoveredDevices devices;
    protected final SavedLinkList youtubeLiveLinks;
    protected final SavedLinkList youtubeLinks;
    protected final SavedLinkList youtubePlaylistLinks;
    protected final SavedLinkList urls;
    protected final Tables tables;
    protected final AppControl appControl;
    protected Sources sources;
    //protected final SavedLinkList urlsFast;


    public Home()
    {
        appControl = new AppControl();
        waiter = new Wait();
        quality = new VideoProperties();
        links = new GetLinks();
        devices = new DiscoveredDevices();
        youtubeLinks = new SavedLinkList(LinksDbHelper.TableName.YOUTUBE_LINKS.getTableName());
        youtubeLiveLinks = new SavedLinkList(LinksDbHelper.TableName.YOUTUBE_LIVE_LINKS.getTableName());
        youtubePlaylistLinks = new SavedLinkList(LinksDbHelper.TableName.YOUTUBE_PLAYLIST_LINKS.getTableName());
        urls = new SavedLinkList(LinksDbHelper.TableName.URLS.getTableName());
        //urlsFast = new SavedLinkList(LinksDbHelper.TableName.URLS_FAST.getTableName());
        tables = new Tables();
    }

    public static AppBack app()
    {
        return AppBack.getApp();
    }
}
