package app;

//import android.content.SharedPreferences;
import android.os.Bundle;

import com.emb.player.R;

import androidx.appcompat.app.AppCompatActivity;
import app.services.BaseServer;
import app.tools.SData;
import io.reactivex.rxjava3.disposables.Disposable;

import static app.tools.DisposableTools.addTask;
import static app.tools.DisposableTools.addTaskUI;
import static app.tools.DisposableTools.forServer;
import static server.Home.app;

public class Permissions extends AppCompatActivity {

    private Disposable appLoader;
    private int savedPort;
    protected PermissionsFunctionality pBase;

    void setup()
    {
        pBase = new PermissionsFunctionality();
        setContentView(R.layout.permissions);
        pBase.baseFunction(this);
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        setup();

        savedPort = pBase.port;

        pBase.portInput.setText(Integer.toString(savedPort));

        pBase.close.setOnClickListener(view ->
        {
            appLoader = addTask(()->{
                if(savedPort != pBase.port)
                {
                    BaseServer.restart();
                }
                appLoader = addTaskUI(()->{
                    finish();
                    return true;
                },()->"PermissionsLoaderFinish");
                return true;
            },()->"PermissionsLoader",forServer);
        });

        pBase.close.setEnabled(true);
        pBase.portInfo.setText("AFTER SET RESTART");

        pBase.portSet.setOnClickListener(view -> {
            pBase.port = Integer.parseInt(pBase.portInput.getText().toString());

            if(pBase.port!=-1)
            {
                SData.setInt(SData.Data.Port, pBase.port);
                //BaseServer.Port(pBase.port);
                //ProcessPhoenix.triggerRebirth(getContext());

                app().sendURL();
                Main.loadUI();
            }
        });
    }

    @Override
    public void onResume()
    {
        super.onResume();
        pBase.autoStartOn = SData.get(SData.Data.AutoStart);

        pBase.autoStart.setChecked(pBase.autoStartOn);
    }

    @Override
    public void onBackPressed()
    {}
}
