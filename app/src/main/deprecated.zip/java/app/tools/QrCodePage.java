package app.tools;

import android.graphics.Bitmap;
import java.text.MessageFormat;
import java.util.Objects;
import app.tools.QRCode.io.nayuki.qrcodegen.QrCode;

public class QrCodePage {
    private final String link;

    public QrCodePage(String ipOrDomain,int port){
        link = MessageFormat.format("{0}:{1}",ipOrDomain,Integer.toString(port));
    }

    public String qrMessage()
    {
        return String.join("\n\n",
                "For the controlling the audio player in another device.",
                MessageFormat.format("Open link in browser:\n{1}{0}",link,"http://"),
                "Or scan the QR code:");
    }

    public Bitmap qrImage()
    {
        return toImage(QrCode.encodeText("http://"+link, QrCode.Ecc.LOW),15,2,0xFFFFFF, 0x000000);
    }

    private Bitmap toImage(QrCode qr, int scale, int border, int lightColor, int darkColor) {
        Objects.requireNonNull(qr);
        if (scale <= 0 || border < 0)
            throw new IllegalArgumentException("Value out of range");
        if (border > Integer.MAX_VALUE / 2 || qr.size + border * 2L > Integer.MAX_VALUE / scale)
            throw new IllegalArgumentException("Scale or border too large");

        Bitmap result = Bitmap.createBitmap((qr.size + border * 2) * scale, (qr.size + border * 2) * scale, Bitmap.Config.RGB_565);
        for (int y = 0; y < result.getHeight(); y++) {
            for (int x = 0; x < result.getWidth(); x++) {
                boolean color = qr.getModule(x / scale - border, y / scale - border);
                result.setPixel(x, y, color ? darkColor : lightColor);
            }
        }
        return result;
    }
}
