package app.tools;

import android.content.Context;
import android.content.SharedPreferences;

import java.util.function.Consumer;

import static android.content.Context.MODE_PRIVATE;

public class SData {

    private static final String dataName = "Em";

    private static Consumer<Context> load = new Consumer<Context>() {
        @Override
        public void accept(Context context) {

            data = context.getSharedPreferences(dataName, MODE_PRIVATE);
            load = context1 -> {};
        }
    };

    private static SharedPreferences data;

    public static void LoadData(Context context)
    {
        load.accept(context);
    }


    public static boolean get(Data key)
    {
        return data.getBoolean(getData(key), false);
    }

    public static boolean get(Data key, boolean ifNull)
    {
        return data.getBoolean(getData(key), ifNull);
    }

    public static void set(Data key, boolean value)
    {
        SharedPreferences.Editor editor = data.edit();
        editor.putBoolean(getData(key), value);
        editor.apply();
    }

    public static int getInt(Data key)
    {
        return data.getInt(getData(key),0);
    }

    public static int getInt(Data key, int outputIfNotHave)
    {
        return data.getInt(getData(key),outputIfNotHave);
    }

    public static void setInt(Data key, int value)
    {
        SharedPreferences.Editor editor = data.edit();
        editor.putInt(getData(key), value);
        editor.apply();
    }



    public static long getLong(Data key)
    {
        return data.getLong(getData(key),0);
    }

    public static long getLong(Data key, long outputIfNotHave)
    {
        return data.getLong(getData(key),outputIfNotHave);
    }

    public static void setLong(Data key, long value)
    {
        SharedPreferences.Editor editor = data.edit();
        editor.putLong(getData(key), value);
        editor.apply();
    }


    public static String getString(Data key)
    {
        return data.getString(getData(key), null);
    }

    public static String getString(Data key, String ifNull)
    {
        return data.getString(getData(key),ifNull);
    }

    public static void setString(Data key, String value)
    {
        SharedPreferences.Editor editor = data.edit();
        editor.putString(getData(key), value);
        editor.apply();
    }

    public static void resetToDefault()
    {
        SData.setString(SData.Data.SavedMedia,null);
        SData.setLong(SData.Data.SavedSeek,0);
        SData.setInt(SData.Data.SavedIndexPlayList,0);
    }

    private static String getData(Data key)
    {
        return dataName+key.name();
    }

    public enum Data {
        AutoStart, OnlyFirstOpen,
        RadioPlayerIndex,PlayerIndex,LivePlayerIndex,
        YoutubeVideoPlayerIndex,YoutubePlayerIndex,
        ResolutionLiveIndex,ResolutionIndex,
        MediaProviderClientSideID,
        LanguageIndex, VolumePosition,
        HardwareDecoding, Port, UndefiledError,
        SavedSeek, SavedLoop,
        StoppingTime, StoppingTimeList,
        SavedIndexPlayList, SavedDisposableErrors,
        SavedListenersErrors, SavedIPorMac,
        SavedTimeOut,SavedTimeOutt,
        SavedJsonNames,SDDTest,
        SavedExtractorPattern,
        SavedExtractorExpirePattern,
        SavedCorrect,SaveErrorAA,
        YoutubeCaching,URLCaching,
        IsSavable, ColorFormatIndex,
        SaveRecoverTriggered, DestroySaves,
        LegacyYoutubePlayer,SavedMedia,SSSS,
        CheckMacAndSsid
    }
}
