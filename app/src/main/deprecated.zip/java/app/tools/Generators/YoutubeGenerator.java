package app.tools.Generators;

import org.schabi.newpipe.extractor.StreamingService;
import org.schabi.newpipe.extractor.exceptions.ExtractionException;
import org.schabi.newpipe.extractor.localization.ContentCountry;
import org.schabi.newpipe.extractor.localization.Localization;
import org.schabi.newpipe.extractor.stream.StreamInfo;
import org.schabi.newpipe.extractor.stream.StreamType;
import org.schabi.newpipe.extractor.stream.VideoStream;

import java.io.IOException;

import app.tools.Generators.Requirements.GeneratorWithExpire;
//import server.tools.HostedContents;
import app.tools.Players.all.PlayerControllerBase;
import app.tools.StaticFunctions;
import server.tools.VideoSettings;

import app.tools.Generators.Requirements.Piped.ContentId;
import app.tools.Generators.Requirements.Piped.NewPipeEx;
import app.tools.Generators.Requirements.Piped.StreamSelectionPolicy;
import app.tools.Generators.Requirements.Piped.VideoQuality;
import app.tools.Generators.Requirements.Piped.VideoResolution;
import app.tools.HlsSelector;
import app.tools.Players.all.Listeners;
import app.tools.Generators.Requirements.YouTubeExpireExtractor;

import server.web.ErrorCodeApp;

import static server.Home.app;

public class YoutubeGenerator extends GeneratorWithExpire {

    protected final VideoSettings videoSettings;
    private final Size size;

    private ContentId id;
    private boolean displayOn;
    private StreamInfo info;

    //private List<String> logs;
    //private List<VideoStream> videoStreamList;
    //private List<VideoStream> videoOnlyStreamList;
    //private List<AudioStream> audioStreams;
    //public String language;

    public YoutubeGenerator(String videoURL,VideoSettings videoSettings,Listeners listeners, boolean hardware)
    {
        super(videoURL,listeners,hardware);
        size = new Size();
        this.videoSettings = videoSettings;
    }

    public static void updateNewPipe()
    {
        NewPipeEx.init(Localization.DEFAULT, ContentCountry.DEFAULT);
    }

    @Override
    public String nameOfMedia() {
        return info.getName();
    }

    @Override
    public void modifyGenerateLink()
    {
        size.width = 0;
        size.height = 0;
    }

    @Override
    public boolean modifyGenerateContent(){
        try {
            id = NewPipeEx.getContentId(videoURL);
            return true;
        }
        catch (Exception e)
        {
            return false;
        }
    }

    public Size getSize()
    {
        return size;
    }

    public PlayerControllerBase onErrorLive(boolean DisplayOn, boolean loop, boolean playlistLoop)
    {
        notLive();
        return startPanel(DisplayOn,loop,playlistLoop);
    }

    public StreamingService.LinkType getType()
    {
        return id.getType();
    }

    @Override
    public void modifyGenerateInfo() throws ExtractionException, IOException {
        info = NewPipeEx.getStreamInfoById(id.getId());
    }
/*
    public void GenerateInfoOnlyAudio() throws ExtractionException, IOException {
        info = NewPipeEx.getCustomStreamInfoByVideoIdOnlyAudio(id.getId());
    }*/

    public StreamInfo getInfo() {
        return info;
    }

    public void generateInfoAuto() throws ExtractionException, IOException {
        generateInfo();/*
        if(!DisplayOn)
            GenerateInfoOnlyAudio();
        else
            GenerateInfo();*/
    }
    //Panel.AspectChange(width, height);
    //Panel.RefreshDisplay();

    @Override
    protected void modifyLoadContent(){

        //StreamingService.LinkType type = id.getType();
        //if(type== StreamingService.LinkType.PLAYLIST)

        if(!live())
            notLive();
    }

    private void notLive()
    {
        isLive = false;
        ErrorCodeApp.code53 = ErrorCodeApp.code53 + "_A8112FxCA";
        //contentType = ContentTypes.TYPE_OTHER;

        maxSeek.maxSeek=info.getDuration()*1000;

        ErrorCodeApp.code53 = ErrorCodeApp.code53 + "_AFxCA853";

        StreamSelectionPolicy.StreamSelection selection = null;

        try {

            ErrorCodeApp.code53 = ErrorCodeApp.code53 + "_displayOn:"+(displayOn);

            ErrorCodeApp.code53 = ErrorCodeApp.code53 + "_infoIsNull:"+(info==null);

            ErrorCodeApp.code53 = ErrorCodeApp.code53 + "_videoSettingsIsNull:"+(videoSettings==null);

            VideoResolution l = videoSettings.resolution();

            ErrorCodeApp.code53 = ErrorCodeApp.code53 + "_videoResolutionIsNull:"+(l==null);

            VideoQuality ll = videoSettings.quality();

            ErrorCodeApp.code53 = ErrorCodeApp.code53 + "_videoQualityIsNull:"+(ll==null);

            String lang = videoSettings.languageISO2();

            ErrorCodeApp.code53 = ErrorCodeApp.code53 + "_langIsNull:"+(lang==null);

            StreamSelectionPolicy streamS = new StreamSelectionPolicy(true,l, VideoResolution._144P, ll,lang);

            ErrorCodeApp.code53 = ErrorCodeApp.code53 + "_streamSelectionPolicyIsNull:"+(streamS==null);

            selection = streamS.select(info,!displayOn);

            ErrorCodeApp.code53 = ErrorCodeApp.code53 + "_selectionIsNull:"+(selection==null);
        }
        catch (Exception e){
            StaticFunctions.onErrorSave("Create_Stream_Selection_Policy",e);
        }

        ErrorCodeApp.code53 = ErrorCodeApp.code53 + "_A95qw2FxCA";
        try
        {
            if(app().legacyYoutubePlayer.make())
            {
                ErrorCodeApp.code53 = ErrorCodeApp.code53 + "_AF9055xCA";
                VideoStream videoStreamIn = selection.getVideoStream();
                ErrorCodeApp.code53 = ErrorCodeApp.code53 + "_A25Fx4CA";
                audioOrBaseStream = videoStreamIn.getContent();
                ErrorCodeApp.code53 = ErrorCodeApp.code53 + "_AFxCA85";
                if(displayOn){
                    updateSize(videoStreamIn);
                    ErrorCodeApp.code53 = ErrorCodeApp.code53 + "_4A72FxCA";
                }
                ErrorCodeApp.code53 = ErrorCodeApp.code53 + "_fw22AFxCA";
                return;
            }

            ErrorCodeApp.code53 = ErrorCodeApp.code53 + "_AFx743CA";
            audioOrBaseStream = selection.getAudioStream().getContent();
        }
        catch (Exception e)
        {
            ErrorCodeApp.code53 = ErrorCodeApp.code53 + "_AFxr42CA";
            videoStream = null;
            return;
        }

        //HostedContents.GetAudioOrBase().UpdateContent(audioOrBaseStream);

        ErrorCodeApp.code53 = ErrorCodeApp.code53 + "_AFxC74A";
        expireSeconds = Integer.parseInt(YouTubeExpireExtractor.extractExpire(audioOrBaseStream));

        ErrorCodeApp.code53 = ErrorCodeApp.code53 + "_AF8332xCA";
        if(displayOn)
        {
            ErrorCodeApp.code53 = ErrorCodeApp.code53 + "_AF8442x4CA";
            VideoStream videoStreamIn = selection.getVideoStream();

            ErrorCodeApp.code53 = ErrorCodeApp.code53 + "_AFxC743A";
            updateSize(videoStreamIn);

            ErrorCodeApp.code53 = ErrorCodeApp.code53 + "_A2Fx4CA";
            videoStream = videoStreamIn.getContent();

            ErrorCodeApp.code53 = ErrorCodeApp.code53 + "_AF3xCA63333";
            //HostedContents.GetVideo().UpdateContent(videoStream);

            int videoTime = Integer.parseInt(YouTubeExpireExtractor.extractExpire(videoStream));

            ErrorCodeApp.code53 = ErrorCodeApp.code53 + "_A2F6xC4A";
            if(expireSeconds>videoTime)
                expireSeconds = videoTime;
        }

        ErrorCodeApp.code53 = ErrorCodeApp.code53 + "_A7F3xC2A";
        //language = GetLanguages()[GetVideoLanguageID()];
        //audioStreams = info.getAudioStreams();
        //videoOnlyStreamList = info.getVideoOnlyStreams();
        //videoStreamList = info.getVideoStreams();
    }

    private boolean live()
    {
        ErrorCodeApp.code53 = ErrorCodeApp.code53 + "_ACAs";
        StreamType streamType = info.getStreamType();
        ErrorCodeApp.code53 = ErrorCodeApp.code53 + "_AFxCA";
        if (streamType == StreamType.LIVE_STREAM || streamType == StreamType.AUDIO_LIVE_STREAM) {
            ErrorCodeApp.code53 = ErrorCodeApp.code53 + "_AFxq1CA";
            try {
                maxSeek.maxSeek = 0;
                ErrorCodeApp.code53 = ErrorCodeApp.code53 + "_2AFxCA";

                if (!info.getHlsUrl().isEmpty()){
                    ErrorCodeApp.code53 = ErrorCodeApp.code53 + "_A54FxCA";
                    displayOn = videoSettings.resolutionLive() != VideoResolution.Audio;
                    ErrorCodeApp.code53 = ErrorCodeApp.code53 + "_A64FxCA";
                    return hlsAdd(info.getHlsUrl());
                }

                /*
                else if (!info.getDashMpdUrl().isEmpty()){
                    return false;
                }*/
            } catch (final Exception e) {}
        }

        ErrorCodeApp.code53 = ErrorCodeApp.code53 + "_A642FxCA";
        displayOn = videoSettings.resolution() != VideoResolution.Audio;
        ErrorCodeApp.code53 = ErrorCodeApp.code53 + "_A841FxCA";
        return false;
    }

    private boolean hlsAdd(String url)
    {
        boolean qualityOn = videoSettings.quality() == VideoQuality.BEST_QUALITY;
        try
        {
            audioOrBaseStream = HlsSelector.addLiveSource(url,qualityOn, HlsSelector.getRes(1), HlsSelector.getRes(videoSettings.resolutionLive().ordinal()));

            //HostedContents.GetAudioOrBase().UpdateContent(audioOrBaseStream);

            expireSeconds = Integer.parseInt(YouTubeExpireExtractor.extractExpire(audioOrBaseStream));

            isLive = true;
            //contentType = ContentTypes.TYPE_HLS;

            return true;
        }
        catch (Exception e)
        {
            return false;
        }
    }

    private void updateSize(VideoStream videoStream)
    {
        size.width = videoStream.getWidth();
        size.height = videoStream.getHeight();
    }

    public static final class Size
    {
        private int width;
        private int height;

        public int getWidth(){
            return width;
        }

        public int getHeight(){
            return height;
        }
    }
}
