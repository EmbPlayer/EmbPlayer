package app.tools.Generators;

import app.tools.Generators.Requirements.Generator;
import app.tools.Players.all.Listeners;
import app.tools.Players.PlayerController;
import app.tools.Players.all.PlayerControllerBase;

public class UrlGenerator extends Generator {

    private final String nameOfMedia;
    private final Listeners listeners;
    private final boolean hardware;

    public UrlGenerator(boolean isLive,String url, Listeners listeners, boolean hardware,String nameOfMedia)
    {
        this.isLive = isLive;
        this.videoURL = url;
        this.listeners = listeners;
        this.hardware = hardware;
        this.nameOfMedia = nameOfMedia;
    }

    @Override
    public PlayerControllerBase startPanel(boolean DisplayOn, boolean loop, boolean plalistLoop) {
        return PlayerController.getPlayer(listeners,loop,plalistLoop,hardware,DisplayOn, isLive(),videoURL,null);
    }

    @Override
    public String nameOfMedia() {
        return nameOfMedia;
    }
}
