package app.tools.Generators.Requirements;

import androidx.annotation.NonNull;
import app.tools.StaticFunctions;

public enum MediaSourceProviders {

    YOUTUBE,
    VIDEO_URL,
    LIVE_VIDEO_URL,
    AUDIO_URL,
    LIVE_AUDIO_URL,
    EXTRACTOR_AUDIO,
    EXTRACTOR;

    public int id(){
        return this.ordinal();
    }

    public enum ClientSide {

        YOUTUBE("Youtube"),
        VIDEO_URL("Video URL"),
        LIVE_VIDEO_URL("Live Video URL"),
        AUDIO_URL("Audio URL"),
        LIVE_AUDIO_URL("Live Audio URL");

        private final String output;

        ClientSide(String output) {
            this.output = output;
        }

        public int id(){
            return this.ordinal();
        }

        @NonNull
        @Override
        public String toString() {
            return output;
        }

        public static String[] getAllMediaSourceTypeName() {
            MediaSourceProviders.ClientSide[] mediaSourceTypes = MediaSourceProviders.ClientSide.values();
            String[] mediaSourceTypesNames = new String[mediaSourceTypes.length];

            for (int i = 0;  i < mediaSourceTypesNames.length;  i++) {
                mediaSourceTypesNames[i] = StaticFunctions.asJsonFormat(mediaSourceTypes[i].toString());
            }

            return mediaSourceTypesNames;
        }
    }
}
