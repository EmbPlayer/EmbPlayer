package app.tools.Generators.Requirements;


import org.schabi.newpipe.extractor.exceptions.ExtractionException;

import java.io.IOException;

import app.tools.Players.PlayerController;
import app.tools.Players.all.PlayerControllerBase;
import app.tools.SData;
import app.tools.StaticFunctions;

import app.tools.Players.all.Listeners;

import app.tools.DisposableTools.WaitDisposable;
import server.web.ErrorCodeApp;

import static app.tools.DisposableTools.killAll;
import static app.tools.StaticFunctions.onErrorSave;

public abstract class GeneratorWithExpire extends Generator {

    public final WaitDisposable mediaSession;
    private final Listeners listeners;
    private final boolean hardware;

    protected boolean isLoaded;
    protected int expireSeconds;

    protected String audioOrBaseStream;
    protected String videoStream;

    public GeneratorWithExpire(String videoURL,Listeners listeners, boolean hardware)
    {
        mediaSession = new WaitDisposable();//12600
        this.videoURL = videoURL;
        this.listeners = listeners;
        this.hardware = hardware;
    }

    @Override
    public void kill()
    {
        isKilled = true;
        killAll(mediaError,mediaSession);
    }

    public final WaitDisposable[] makeKillAnotherWhereAll()
    {
        isKilled = true;
        return new WaitDisposable[] {mediaError,mediaSession};
    }

    @Override
    public final PlayerControllerBase startPanel(boolean DisplayOn, boolean loop, boolean plalistLoop) {
        PlayerControllerBase mediaPlayer = null;

        try {
            mediaPlayer = PlayerController.getPlayer(listeners,loop,plalistLoop,hardware,DisplayOn, isLive(),audioOrBaseStream,videoStream);

            if(mediaPlayer==null)
                return onErrorLive(DisplayOn,loop,plalistLoop);
            else
                mediaPlayer.setMaxSeek(getMaxSeekForPlayer());
        }
        catch (Exception e)
        {
            onErrorSave("GeneratorWithExpire-StartPanel",e);
            return onErrorLive(DisplayOn,loop,plalistLoop);
        }

        return mediaPlayer;
    }

    public final void reloadContent() throws ExtractionException, IOException {
        generateInfo();
        loadContent();
    }

    public final boolean generateAndLoad(int expireSeconds) throws ExtractionException, IOException {

        if(generateLink(expireSeconds))
            reloadContent();

        return isLoaded;
    }

    public final boolean mediaSessionWorking()
    {
        return mediaSession.started;
    }

    public final boolean mediaIsExpired()
    {
        return !mediaSessionWorking()|| StaticFunctions.getCurrentTimeAsSeconds()> expireTime();
    }


    public final int expireTime()
    {
        return expireSeconds;
    }

    public final boolean generateLink(int secondsTimeout)
    {
        modifyGenerateLink();
        int i = 0;
        while (!generateContent())
        {
            if(i==secondsTimeout)
                return false;
            i++;
        }
        return true;
    }

    public final boolean generateContent(){
        expireSeconds = 0;
        audioOrBaseStream = null;
        videoStream = null;

        return modifyGenerateContent();
    }

    public final void loadContent(){
        ErrorCodeApp.code53 = ErrorCodeApp.code53 + "_ACA";
        modifyLoadContent();
        ErrorCodeApp.code53 = ErrorCodeApp.code53 + "_AA";
        isLoaded = true;
        ErrorCodeApp.code53 = ErrorCodeApp.code53 + "_AAL";
        mediaSessionStart();
        ErrorCodeApp.code53 = ErrorCodeApp.code53 + "_ASA";
    }
    public final boolean IsLoaded()
    {
        return isLoaded;
    }

    public final String getAudioStream()
    {
        return audioOrBaseStream;
    }

    public final String getVideoStream()
    {
        return videoStream;
    }

    public final boolean isNotGenerated()
    {
        return audioOrBaseStream==null;
    }

    public final void generateInfo() throws ExtractionException, IOException{
        modifyGenerateInfo();
    };

    public abstract PlayerControllerBase onErrorLive(boolean DisplayOn, boolean loop, boolean playListLoop);
    protected abstract void modifyGenerateLink();
    protected abstract boolean modifyGenerateContent();
    protected abstract void modifyLoadContent();
    protected abstract void modifyGenerateInfo() throws ExtractionException, IOException;

    private void mediaSessionStart() {
        String oout = "[{Starting-MediaSessionStart";
        mediaSession.started = true;

        int waitTime;
        int currentUnixTime = 0;
        if(expireSeconds<1)
        {
            //waitTime = 10800;
            waitTime = 10800;
        }
        else
        {
            currentUnixTime = StaticFunctions.getCurrentTimeAsSeconds();
            int minutes10 = 600;
            waitTime = expireSeconds-currentUnixTime-minutes10;
        }

        oout = oout +"-WaitTime: "+waitTime+"-TriggeredTime: "+currentUnixTime+"-ExpireTime: "+expireSeconds+"}]";
        SData.setString(SData.Data.SavedTimeOut,SData.getString(SData.Data.SavedTimeOut)+oout);


        mediaSession.setSecond(waitTime);

        mediaSession.startWithLongWaiting(o -> {}, () -> {
            mediaSession.started = false;

            mediaErrorRun();

            mediaSession.disposable.dispose();
        }, o -> {
            onErrorSave("YoutubeGenerator-MediaSessionError: ",o);
            mediaSession.disposable.dispose();
        });
    }
}

