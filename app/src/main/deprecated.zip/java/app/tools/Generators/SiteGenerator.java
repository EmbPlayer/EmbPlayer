package app.tools.Generators;

import org.schabi.newpipe.extractor.exceptions.ExtractionException;

import java.io.IOException;

import app.tools.Generators.Requirements.GeneratorWithExpire;
import ssl.SiteLoader;
import app.tools.HlsSelector;
import app.tools.Players.all.Listeners;
import app.tools.Players.all.PlayerControllerBase;
import server.web.ErrorCodeApp;

import static app.tools.DisposableTools.waitMS;

public class SiteGenerator extends GeneratorWithExpire {
    private final String urlPattern;
    private final String expireUnixTimePattern;
    private final String selectedRes;
    private final String nameOfMedia;
    private SiteLoader loader;

    public SiteGenerator(String selectedRes, String videoURL, Listeners listeners, boolean hardware, boolean isLive, String urlPattern, String expireUnixTimePattern,String nameOfMedia) {
        super(videoURL, listeners, hardware);
        this.urlPattern = urlPattern;
        this.expireUnixTimePattern = expireUnixTimePattern;
        this.selectedRes = selectedRes;
        this.isLive = isLive;
        this.nameOfMedia = nameOfMedia;
    }

    @Override
    public void modifyGenerateInfo() throws ExtractionException, IOException {
        loader =  loaderGenerate();
    }

    @Override
    public PlayerControllerBase onErrorLive(boolean DisplayOn, boolean loop, boolean playListLoop) {
        return null;
    }

    @Override
    public String nameOfMedia() {
        return nameOfMedia;
    }

    @Override
    protected void modifyGenerateLink() {}

    @Override
    protected boolean modifyGenerateContent()
    {
        try {
            loader = loaderGenerate();
            return true;
        } catch (Exception e) {
            ErrorCodeApp.code32 = ErrorCodeApp.code32 + "[Failed to create loader: " + e.getMessage() + "]";
            return false;
        }
    }

    @Override
    protected void modifyLoadContent() {
        expireSeconds = -1;
        loader.startCapture();
        for(int i = 0; i<50; i++)
        {
            waitMS(200);
            if(expireSeconds!=-1)
                break;
        }

        if(selectedRes!=null)
            audioOrBaseStream = HlsSelector.getCorrectUrl(audioOrBaseStream,selectedRes);

        loader.stop();
    }

    private SiteLoader loaderGenerate()
    {
        ErrorCodeApp.code36 = ErrorCodeApp.code36+"[OK12"+", expire: "+expireSeconds+", m3u8: "+audioOrBaseStream+", res"+selectedRes+"]";
        return new SiteLoader(videoURL, new SiteLoader.Listeners() {

            @Override
            public void onRequestIntercepted(String url, String method) {
                ErrorCodeApp.code32 = ErrorCodeApp.code32 + "[📡 " + method + " " + url + "]";
            }

            @Override
            public void onError(String errorMessage) {
                ErrorCodeApp.code32 = ErrorCodeApp.code32 + "[❌ Error: " + errorMessage + "]";
            }

            @Override
            public void onMainSiteLoaded(String htmlContent) {
                ErrorCodeApp.code32 = ErrorCodeApp.code32 + "[HTML content length: " + htmlContent.length() + " characters]";
                ErrorCodeApp.code32 = ErrorCodeApp.code32 + "[" + htmlContent + "]";
                //ErrorCodeApp.code32 = ErrorCodeApp.code32 + "[" + htmlContent + "]";

                // Extract the main URL pattern
                audioOrBaseStream = SiteLoader.extractString(urlPattern, htmlContent);

                if (audioOrBaseStream != null) {
                    // Extract expire time if pattern exists
                    String expireStr = SiteLoader.extractString(expireUnixTimePattern, audioOrBaseStream);
                    if (expireStr != null) {
                        try {
                            expireSeconds = Integer.parseInt(expireStr);
                            ErrorCodeApp.code32 = ErrorCodeApp.code32 + "[Expire time: " + expireSeconds + "]";
                        } catch (NumberFormatException e) {
                            ErrorCodeApp.code32 = ErrorCodeApp.code32 + "[Invalid expire time format: " + expireStr + "]";
                            expireSeconds = -1;
                        }
                    }
                    ErrorCodeApp.code32 = ErrorCodeApp.code32 + "[" + audioOrBaseStream + "]";
                } else {
                    ErrorCodeApp.code32 = ErrorCodeApp.code32 + "[URL pattern not found in HTML]";
                    expireSeconds = -1;
                }
            }

            @Override
            public void onLog(String logMessage) {
                ErrorCodeApp.code32 = ErrorCodeApp.code32 + "[" + logMessage + "]";
            }
        });
    }
}