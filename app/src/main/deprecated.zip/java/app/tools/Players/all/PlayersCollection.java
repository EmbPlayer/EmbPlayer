package app.tools.Players.all;

public enum PlayersCollection {
    OEM,IJK,EXO,VLC;
}
