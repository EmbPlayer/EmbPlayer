package app.tools.Players.all;

import android.view.SurfaceHolder;

public interface IVideoPlayer {


    void setDisplay(SurfaceHolder holder);

    void nullDisplay();

    //void DataLink(String audioLink,String videoLink);

    void setScreenOnWhilePlaying(boolean on);

    void refreshDisplay(SurfaceHolder holder);
}
