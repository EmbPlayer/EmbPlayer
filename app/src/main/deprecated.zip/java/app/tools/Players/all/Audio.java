package app.tools.Players.all;

public abstract class Audio<T extends Player> extends Media<T>
{
    private BaseData baseData;

    public Audio(Listeners listeners) {
        super(listeners);
    }

    @Override
    protected void runInConstructor()
    {
        super.runInConstructor();
        baseData = new BaseData();
    }

    @Override
    protected BaseData baseData()
    {
        return baseData;
    }
}