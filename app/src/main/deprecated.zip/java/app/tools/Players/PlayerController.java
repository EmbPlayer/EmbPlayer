package app.tools.Players;

import app.tools.Players.all.Listeners;
import app.tools.Players.all.PlayerControllerBase;

public abstract class PlayerController extends PlayerControllerChangeable {

    public PlayerController(Listeners listeners) {
        super(listeners);
    }

    public static PlayerControllerBase getPlayer(Listeners listeners, boolean loop,
                                                 boolean playlistLoop, boolean HardwareDecoding,
                                                 boolean video, boolean LiveStream,
                                                 String AudioOrBaseStream, String VideoStream)
    {
        return controllerBase.getPlayer(listeners,loop,playlistLoop,HardwareDecoding,video,LiveStream,AudioOrBaseStream,VideoStream);
    }
}
