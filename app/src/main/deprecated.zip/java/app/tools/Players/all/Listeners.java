package app.tools.Players.all;

public abstract class Listeners
{
    public void onBufferingUpdateListener(int percent){}

    public void onErrorListener(){}

    public void onCompletionListener(){}

    public void onStarted(){}

    public void onPlayListLoop(){}

    public void onBufferingStart(){}

    public void onBufferingEnd(){}

    public void onVideoSizeChangedListener(int width, int height){}

    public abstract void onNotLoadedTryAgainToLoad();
}
