package app;

import android.os.Bundle;

import app.tools.SData;
import io.reactivex.rxjava3.disposables.Disposable;

import static app.tools.DisposableTools.addTask;
import static app.tools.DisposableTools.addTaskUI;
import static app.tools.DisposableTools.forServer;

public class OnFirstLaunch extends Permissions{
    private Disposable appLoader;
    
    @Override
    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);

        setup();

        pBase.portSet.setOnClickListener(view -> {

            pBase.port = Integer.parseInt(pBase.portInput.getText().toString());

            if(pBase.port!=-1)
            {
                SData.setInt(SData.Data.Port, pBase.port);

                pBase.close.setOnClickListener(view1 -> {
                    appLoader = addTask(()->{
                        Main.startServiceFromDifferentActivityOrHere();
                        appLoader = addTaskUI(()->{
                            finish();
                            return true;
                        },()->"OnFirstLoaderClose");
                        return true;
                    },()->"OnFirstLoader",forServer);
                });
                pBase.close.setEnabled(true);
            }
        });

        SData.set(SData.Data.OnlyFirstOpen,true);
    }
    
}
