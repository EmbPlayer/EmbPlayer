/*
 * SPDX-License-Identifier: GPL-3.0-or-later
 * Copyright 2026-present Emre Hyuseinov (plaxir) <plaxirstudio@gmail.com>
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <https://www.gnu.org/licenses/>.
 */

package server.tools;

import android.content.Context;
import android.os.Build;
import android.util.Log;

import com.github.druk.rx2dnssd.BonjourService;
import com.github.druk.rx2dnssd.Rx2Dnssd;
import com.github.druk.rx2dnssd.Rx2DnssdEmbedded;

import java.net.UnknownHostException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Objects;
import java.util.concurrent.Callable;

import app.Main;
import app.services.BaseServer;
import io.reactivex.android.schedulers.AndroidSchedulers;
import io.reactivex.rxjava3.disposables.Disposable;
import io.reactivex.schedulers.Schedulers;

import static app.tools.DisposableTools.addTask;
import static app.tools.DisposableTools.forkJoinPool;

public class UniversalMDNS {

    private static UniversalMDNS host;

    private Context context;
    private String serviceName;

    private Disposable registered;
    private Rx2Dnssd register;
    private io.reactivex.disposables.Disposable registerBackup;

    private io.reactivex.disposables.Disposable browseDisposable;
    // Create a list to hold our discovered services
    private List<BonjourService> discoveredServices;

    public UniversalMDNS(String serviceName,Context context) throws UnknownHostException {

        host = this;
        this.serviceName = serviceName;
        this.context = context;

        registered = addTask(() -> {
            base();
            updateListTrigger();
            return true;
        },() -> "UniversalMDNS",forkJoinPool);
    }

    public static List<BonjourService> devices()
    {
        return host.discoveredServices;
    }

    public static void removeDevice(int index)
    {
        host.discoveredServices.remove(index);
    }

    public static void refreshMDns()
    {
        host.stopAdvertisement();

        host.registered = addTask(() -> {

            host.registered = addTask(() -> {
                host.base();
                return true;
            },() -> "UniversalMDNS-RefreshMDns-Base",forkJoinPool);

            return true;
        },() -> "UniversalMDNS-RefreshMDns",forkJoinPool);
    }

    public boolean isHave(BonjourService device, String txtKey)
    {
        String deviceName = device.getTxtRecords().get(txtKey);

        for(BonjourService ddevice : discoveredServices)
        {
            if(Objects.equals(ddevice.getTxtRecords().get(txtKey), deviceName))
                return true;
        }
        return false;
    }

    public void updateListTrigger()
    {
        host.discoveredServices = new ArrayList<>();

        host.browseDisposable = host.register.browse("_http._tcp", "local.")
                .compose(host.register.resolve())
                .compose(host.register.queryRecords())
                .subscribeOn(Schedulers.newThread())
                .observeOn(Schedulers.newThread())
                .subscribe(bonjourService -> {

                    if (bonjourService.isLost()) {
                        // Remove the lost service from the list
                        host.discoveredServices.remove(bonjourService);
                    } else {
                        // Add the new service to the list
                        if(!host.isHave(bonjourService,"hostname_link"))
                            host.discoveredServices.add(bonjourService);
                    }

                }, throwable -> Log.e("TAG", "error", throwable));
    }

    public void stopAdvertisement() {
        if (registerBackup != null && !registerBackup.isDisposed()) {
            registerBackup.dispose();
        }
        if (registered != null && !registered.isDisposed()) {
            registered.dispose();
        }
    }

    private HashMap<String,String> setup(String ip, int port, Context context)
    {
        register = new Rx2DnssdEmbedded(context);

        HashMap<String,String> txt = new HashMap<>();

        txt.put("ip_link", createLink(ip,port));

        return txt;
    }

    private HashMap<String,String> setup(String ip4Hostname, String ip, int port, Context context)
    {

        register = new Rx2DnssdEmbedded(context);

        HashMap<String,String> txt = new HashMap<>();

        txt.put("ip_link", createLink(ip,port));
        txt.put("hostname_link", createLink(ip4Hostname,port));
        txt.put("hostname_linkV2", createLink(ip4Hostname+".lan",port));
        txt.put("device",Build.BRAND+" "+Build.MODEL);

        return txt;
    }

    private String createLink(String directory, int port)
    {
        return "http://"+directory+":"+port;
    }

    private void base() throws UnknownHostException {
        BaseServer.updateLocalhost();
        Main.qrSetup();

        HashMap<String,String> txt;

        String ipOrHostname = BaseServer.getLocalhost();

        if(BaseServer.isHaveHostname())
            txt = setup(ipOrHostname,BaseServer.getIP(),BaseServer.getPort(),context);
        else
            txt = setup(BaseServer.getIP(),BaseServer.getPort(),context);

        String serviceName = this.serviceName+"_"+Build.DEVICE+"_"+ipOrHostname;

        BonjourService bs = new BonjourService.Builder(0, 0, serviceName, "_http._tcp", null)
                .port(BaseServer.getPort())
                .dnsRecords(txt)
                .build();

        registerBackup = register.register(bs)
                .subscribeOn(Schedulers.newThread())
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe(
                        service -> Log.d("MDNS", "Service registered: " + service),
                        throwable -> Log.e("MDNS", "Error registering", throwable)
                );
    }
}