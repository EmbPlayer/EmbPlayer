/*
 * SPDX-License-Identifier: GPL-3.0-or-later
 * Copyright 2026-present Emre Hyuseinov (plaxir) <plaxirstudio@gmail.com>
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <https://www.gnu.org/licenses/>.
 */

package server.tools;

import android.content.Context;
import android.net.wifi.WifiManager;

import org.xbill.DNS.Name;
import org.xbill.mDNS.MulticastDNSService;
import org.xbill.mDNS.ServiceInstance;
import org.xbill.mDNS.ServiceName;

import java.net.InetAddress;

import io.reactivex.rxjava3.disposables.Disposable;

import static app.tools.DisposableTools.addTask;
import static app.tools.DisposableTools.forkJoinPool;

public class Mdns {

    private MulticastDNSService mDNSService;
    private WifiManager.MulticastLock multicastLock;
    private Disposable mdnsTask;

    public Mdns(Context context, String instanceName, String hostName, String ip, int port) {
        mdnsTask = addTask(() -> {
            WifiManager wifi = (WifiManager) context.getApplicationContext()
                    .getSystemService(Context.WIFI_SERVICE);
            multicastLock = wifi.createMulticastLock("mdns_lock");
            multicastLock.setReferenceCounted(true);
            multicastLock.acquire();

            try {
                // 1. PROPER SERVICE NAME CONSTRUCTION
                String fullServiceName = instanceName + "._http._tcp.local.";
                ServiceName name = new ServiceName(fullServiceName);

                // 2. HOSTNAME MUST END WITH DOT
                Name hName = new Name(hostName.endsWith(".") ? hostName : hostName + ".");

                // 3. IP ADDRESS
                InetAddress ip4 = InetAddress.getByName(ip);

                // 4. MANDATORY TXT RECORDS
                String[] txtRecords = {
                        /*"txtvers=1",*/
                        "ip="+ip,
                        "hostname="+ip4.getHostName()
                };

                // 5. CREATE INSTANCE
                ServiceInstance instance = new ServiceInstance(
                        name, 0, 0, port, hName,
                        new InetAddress[]{ip4},
                        txtRecords
                );

                // 6. REGISTER SERVICE
                mDNSService = new MulticastDNSService();
                mDNSService.register(instance);

            } catch (Exception e) {
                e.printStackTrace();
                return false;
            }
            return true;
        },() -> "Mdns",forkJoinPool);
    }

    public void stopAdvertisement() {
        if (mdnsTask != null && !mdnsTask.isDisposed()) {
            mdnsTask.dispose();
        }
    }
}
