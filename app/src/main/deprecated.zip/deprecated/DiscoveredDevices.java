/*
 * SPDX-License-Identifier: GPL-3.0-or-later
 * Copyright 2026-present Emre Hyuseinov (plaxir) <plaxirstudio@gmail.com>
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <https://www.gnu.org/licenses/>.
 */

package server.web;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import javax.jmdns.ServiceInfo;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import app.tools.StaticFunctions;
import server.tools.HttpServletAdvanced;

import static app.tools.StaticFunctions.asJsonFormat;
import static app.tools.StaticFunctions.Item;

public class DiscoveredDevices extends HttpServletAdvanced {

    private List<Item> devices;

    private boolean updateDevices()
    {
        devices = new ArrayList<>();/*

        for(BonjourService device : UniversalMDNS.Devices())
        {
            //devices.add(device.getHostname());
            Map<String,String> txt = device.getTxtRecords();
            devices.add(new Item(txt.get("device"),txt.get("hostname_link")));
        }*/

        List<ServiceInfo> getDevices = null/*JmdnsHost.Devices()*/;

        if(getDevices==null)
            return false;
/*
        for(ServiceInfo device : getDevices) {
            // JmDNS provides direct methods to access TXT record values as strings
            String deviceName = device.getPropertyString("device");
            String hostnameLink = device.getPropertyString("hostname_link");

            devices.add(new Item(deviceName, hostnameLink));
        }*/

        return false;
    }

    @Override
    protected void doGetAdvanced(HttpServletRequest req, HttpServletResponse resp) throws IOException {

        if(!updateDevices())
            return;

        resp.getWriter().write(StaticFunctions.setData(StaticFunctions.itemAsJson(devices)));
    }
}
