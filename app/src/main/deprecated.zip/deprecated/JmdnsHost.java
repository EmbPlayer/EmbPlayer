/*
 * SPDX-License-Identifier: GPL-3.0-or-later
 * Copyright 2026-present Emre Hyuseinov (plaxir) <plaxirstudio@gmail.com>
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <https://www.gnu.org/licenses/>.
 */

package server.tools;

import android.os.Build;
import android.util.Log;

import javax.jmdns.JmDNS;
import javax.jmdns.ServiceEvent;
import javax.jmdns.ServiceInfo;
import javax.jmdns.ServiceListener;

import java.io.IOException;
import java.net.InetAddress;
import java.net.UnknownHostException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.Callable;

import app.services.BaseServer;
import io.reactivex.rxjava3.disposables.Disposable;

import static app.tools.DisposableTools.addTask;
import static app.tools.DisposableTools.forkJoinPool;

public class JmdnsHost {

    private static JmDNS jmdns;
    private static Disposable mdnsHost;
    private static String serviceName;
    private static boolean loaded;

    private final ServiceListener serviceListener = new ServiceListener() {
        @Override
        public void serviceAdded(ServiceEvent event) {
            // Service discovered, resolve it to get details
            jmdns.requestServiceInfo(event.getType(), event.getName(), true);
        }

        @Override
        public void serviceRemoved(ServiceEvent event) {
            // Service lost - remove from list
            ServiceInfo removedService = event.getInfo();
            if (removedService != null) {
                discoveredServices.removeIf(service ->
                        service.getName().equals(removedService.getName()) &&
                                service.getType().equals(removedService.getType())
                );
            }
        }

        @Override
        public void serviceResolved(ServiceEvent event) {
            // Service details resolved
            ServiceInfo resolvedService = event.getInfo();
            if (resolvedService != null && !isHave(resolvedService, "hostname_link")) {
                // Check if service already exists to avoid duplicates
                boolean exists = discoveredServices.stream()
                        .anyMatch(service ->
                                service.getName().equals(resolvedService.getName()) &&
                                        service.getType().equals(resolvedService.getType())
                        );

                if (!exists) {
                    discoveredServices.add(resolvedService);
                }
            }
        }
    };
    private List<ServiceInfo> discoveredServices = new ArrayList<>();
    private Disposable mdnsDiscover;


    /*
        public static List<ServiceInfo> Devices()
        {
            if(host!=null)
                return host.discoveredServices;
            return null;
        }*/

    public static void create(String name) throws IOException {

        serviceName = name;

        start();

        /*


        do
        {
            AppBack.Wait(500);
        }
        while (!loaded);

        mdnsDiscover = AppBack.NewDisposable((Callable<Boolean>) () -> {

            // Clear existing services
            discoveredServices = new ArrayList<>();

            // Remove existing listener if any
            jmdns.removeServiceListener("_http._tcp.local.", serviceListener);

            // Add service listener for HTTP services
            jmdns.addServiceListener("_http._tcp.local.", serviceListener);

            return true;
        });*/
    }

    public static void start() {
        mdnsHost = addTask(() -> {
            base();

            return true;
        }, () -> "Jmdns-Start",forkJoinPool);
    }

    public static void stopAdvertisement() {
        if (mdnsHost != null && !mdnsHost.isDisposed()) {
            mdnsHost.dispose();
        }
        //cleanup();
        /*if (mdnsDiscover != null && !mdnsDiscover.isDisposed()) {
            mdnsDiscover.dispose();
        }*/
    }

    public void cleanup() {
        if (jmdns != null) {
            try {
                jmdns.removeServiceListener("_http._tcp.local.", serviceListener);
                jmdns.close();
            } catch (IOException e) {
                Log.e("TAG", "Error closing JmDNS", e);
            }
        }
    }

    private static HashMap<String, String> setup(String ip4Hostname, String ip, int port) {
        HashMap<String, String> txt = new HashMap<>();

        txt.put("ip_link", createLink(ip, port));
        txt.put("hostname_link", createLink(ip4Hostname, port));
        txt.put("hostname_linkV2", createLink(ip4Hostname + ".lan", port));
        txt.put("device", Build.BRAND + " " + Build.MODEL);

        return txt;
    }

    private static HashMap<String, String> setup(String ip, int port) {
        HashMap<String, String> txt = new HashMap<>();

        txt.put("ip_link", createLink(ip, port));

        return txt;
    }

    private static String createLink(String directory, int port) {
        return "http://" + directory + ":" + port;
    }

    private static void base() throws UnknownHostException {
        //BaseServer.UpdateLocalhost();
        //Main.QrSetup();

        HashMap<String, String> txt;

        String ipOrHostname = BaseServer.getLocalhost();
        int port = BaseServer.getPort();

        if (BaseServer.isHaveHostname())
            txt = setup(ipOrHostname, BaseServer.getIP(), port);
        else
            txt = setup(BaseServer.getIP(), BaseServer.getPort());

        String serviceName = JmdnsHost.serviceName + "_" + Build.DEVICE + "_" + ipOrHostname;

        refresh(ipOrHostname, port, serviceName, txt);
        loaded = true;
    }

    private static void refresh(String ip, int port, String serviceName, Map<String, String> txt) {
        try {/*
            txtProperties.put("ip_link", ip+port);*/
            //jmdns = JmDNS.create(); // binds to active Wi-Fi interface
            InetAddress wifiIp = InetAddress.getByName(ip); // your device IPv4
            jmdns = JmDNS.create(wifiIp);

            //ServiceInfo serviceInfo = ServiceInfo.create("_http._tcp.local.", Build.DEVICE, port, combinedTxt);
            ServiceInfo serviceInfo = ServiceInfo.create("_http._tcp.local.", serviceName, port, 0, 0, false, txt);
            jmdns.registerService(serviceInfo);
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }

    // Helper method equivalent to your host.IsHave() method
    private boolean isHave(ServiceInfo service, String key) {
        // Check if service has the specified property
        return service.getPropertyString(key) != null;
    }
}
